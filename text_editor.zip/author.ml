let hw_n = 2

let hw_c = 2

let hw_b = 4

let hours_worked = hw_n + hw_c + hw_b
