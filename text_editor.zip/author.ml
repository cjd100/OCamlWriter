let hw_n = 35

let hw_c = 37

let hw_b = 36

let hours_worked = hw_n + hw_c + hw_b
